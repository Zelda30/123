# 上海应届生积分落户计算器
> 在线地址：https://canisettleshanghai.now.sh

快来算算你的落户积分吧~

## Project setup
```
yarn install
```

### Compiles and hot-reloads for development
```
yarn serve
```

### Compiles and minifies for production
```
yarn build
```

### Lints and fixes files
```
yarn lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
